package Hongik.Selab.Reverse.Main;

import java.io.IOException;

import Hongik.Selab.Reverse.GenDot.GenerateDot;

public class Main extends Thread {
	public static void main(String[] args) {
		GenerateDot gd = new GenerateDot(args[0].toString());
		try {
			gd.genArchitenture_Class();
			//gd.callCount();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
