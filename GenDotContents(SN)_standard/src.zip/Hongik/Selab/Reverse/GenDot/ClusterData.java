package Hongik.Selab.Reverse.GenDot;

import java.util.LinkedList;

public class ClusterData {
	String m_directoryName;
	LinkedList<String> m_items = new LinkedList<>();
}
