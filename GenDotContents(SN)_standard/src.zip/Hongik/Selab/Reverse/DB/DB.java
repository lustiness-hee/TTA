package Hongik.Selab.Reverse.DB;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import Hongik.Selab.Reverse.GenDot.parse;

public class DB {
	private final int step = 1000;
	public boolean close() {
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException e) {
			return false; 
		}
		return true;
	}

	private static final String dbName = "recoveryDB";
	private Connection conn;

	/**
	 * DB�� �ʱ�ȭ�Ѵ�. 
	 * @return ���� �� false�� ��ȯ�Ѵ�.
	 */
	private boolean initDB(){	
		try {
			// #1. JDBC driver loading
			Class.forName("SQLite.JDBCDriver").newInstance();
			conn = DriverManager.getConnection("jdbc:sqlite:/"+dbName);
		}
		catch (Exception ex) {
			return false;
		}
		return true;
	}

	/**
	 * DB Connection �� ��ȯ�Ѵ�.
	 * @return
	 * @throws Exception 
	 */
	public Connection getConnection() throws Exception{
		if (conn != null)
			return conn;
		initDB();
		return conn;
	}
	
	public boolean init() throws Exception{
		Connection conn = getConnection();

		// #1. Table ���
		Statement stat;
		try {
			stat = conn.createStatement();
			stat.executeUpdate("drop table if exists TEMP_LINK;");
			stat.executeUpdate("create table TEMP_LINK"
					+" (Caller TEXT ,Caller_SYM,Callee TEXT,Callee_SYM, DAT_Count INTEGER, STMP_Count INTEGER, CON_Count INTEGER, EXT_Count INTEGER, COM_Count INTEGER, CONT_Count INTEGER);");
			stat.executeUpdate("drop table if exists library;");
			stat.executeUpdate("create table Library"
					+" (Path text);");
			
			insertModules(new File("./Library.ini"));
			ReplaceSlash();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public void insertLinks(Vector<parse> links) throws Exception {
		Connection conn = getConnection();
		try {
			PreparedStatement prep = conn.prepareStatement("insert or IGNORE into TEMP_LINK values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");
			conn.setAutoCommit(false);	

			for(int i=0;i<links.size(); i++) {
				parse p = links.get(i);
				prep.setString(1, p.getCaller());
				prep.setString(2, p.getCaller_sym());
				prep.setString(3, p.getCallee());
				prep.setString(4, p.getCallee_sym());
				prep.setInt(5, p.getDat_count());
				prep.setInt(6, p.getStmp_count());
				prep.setInt(7, p.getCon_count());
				prep.setInt(8, p.getExt_count());
				prep.setInt(9, p.getCom_count());
				prep.setInt(10, p.getCont_count());
				prep.addBatch();
				
				if ((i % step) == 0) {
					prep.executeBatch();
					conn.commit();
					prep.clearBatch();
					System.out.print(".");
				}
			}

			prep.executeBatch();
			conn.commit();
			prep.clearBatch();
			
			conn.setAutoCommit(true);
			prep.close();
			System.out.println();
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	public void insertModules(File f) throws Exception {
		Connection conn = getConnection();
		BufferedReader br = new BufferedReader(new FileReader(f));
		String read;
		try {
			PreparedStatement prep = conn.prepareStatement("insert or IGNORE into Library values (?);");
			conn.setAutoCommit(false);	
			
			try {
				while((read = br.readLine()) != null){
					prep.setString(1, read.toString());
					prep.addBatch();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			prep.executeBatch();
			conn.commit();
			prep.clearBatch();
			
			conn.setAutoCommit(true);
			prep.close();
			System.out.println("library path input Complete..");
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	
	public void ReplaceSlash(){
		Connection conn;
		Statement stat;
		try {
			conn = getConnection();
			stat = conn.createStatement();
			System.out.println("Replace Start!");
			stat.executeUpdate("update Constants set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update ProjectFiles set highlight_file = replace(highlight_file,\"/\",\"\\\");");
			stat.executeUpdate("update Enumerations set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update EnumConstants set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update FunctionDefinitions set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update Friends set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update Functions set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update Variables set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update Inheritances set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update instanceVariables set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update Macros set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update MethodDefinitions set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update MethodImplementations set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update typedefs set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update RefersTo set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update ReferredBy set filename = replace(filename,\"/\",\"\\\");");
			stat.executeUpdate("update Classes set filename = replace(filename,\"/\",\"\\\");");
			System.out.println("Replace End!");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

	
	